/**
 * New version of the demo project
 * Download on Nov 28
 * Specific Due date TBD
 */
package com.tonyxr.drawingproject;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

public class DrawingDemo extends AppCompatActivity
{
    DemoView demoView;          // custom view for this demo program's Activity (not using
    // R.layout.activity_main that Android Studio provides by default

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main);      // not using the default activity_main XML resource
        demoView = new DemoView(this);
        setContentView(demoView);
    }

    private class DemoView extends View
    {
        public DemoView(Context context)
        {
            super(context);
        }

        @Override protected
        void onDraw(Canvas canvas)
        {
            super.onDraw(canvas);

            int x = 0;          // horizontal placement of graphic shapes
            int y = 0;          // vertical placement of graphic shapes

            int screenWidth = getWidth();      // width of the View object but can be thought of as the canvas width
            int screenHeight = getHeight();    // canvas height (TODO: figure out how to account for height of action bar)

            // creating Paint objects to serve as reusable brushes (fill) and pens (stroke)

            Paint paint = new Paint();              // general, miscellaneous paint tasks

            Paint whiteBrush = new Paint();         // white, filled "paintbrush"
            whiteBrush.setColor(Color.WHITE);
            whiteBrush.setStyle(Paint.Style.FILL);

            Paint redBrush = new Paint();           // red, filled paintbrush
            redBrush.setColor(Color.RED);
            redBrush.setStyle(Paint.Style.FILL);

            Paint greenPen = new Paint();           // green "pen" that does not fill
            greenPen.setColor(Color.GREEN);
            greenPen.setStyle(Paint.Style.STROKE);  // creating a "pen" that does not fill in regions
            greenPen.setStrokeWidth(10);            // width of the pen's stroke
            greenPen.setAntiAlias(true);         // smooth edges

            // paint the background of the View's canvas
            paint.setColor(Color.BLACK);
            canvas.drawPaint(paint);

            // draw concentric circles with in the center of the View's canvas
            int horizontalMiddle = screenWidth / 2;         // x center of circle
            int verticalMiddle = screenHeight / 2;          // y center of circle
            int radius = 100;                               // radius of circle

            for (int i = 0; i < 5; i++)
            {

                if (i % 2 == 0)                             // alternating colors
                {
                    paint = whiteBrush;
                }
                else
                {
                    paint = redBrush;
                }

                canvas.drawCircle(horizontalMiddle, verticalMiddle, radius, paint);
                radius -= 20;
            }

            // TODO: ensure that the small multi-colored squares land completely inside of the large green rectangle

            // draw a green rectangle
            int rectangleWidth = screenWidth;               // width of the rectangle
            int rectangleHeight = 300;                      // height of the rectangle
            int rectangleLeftEdge = 0;                      // left edge of the rectangle
            int rectangleRightEdge = screenWidth;           // right edge of the rectangle
            int rectangleTopEdge = 1000;                    // top edge of the rectangle

            paint.setColor(Color.GREEN);
            canvas.drawRect(rectangleLeftEdge, rectangleTopEdge, rectangleLeftEdge + rectangleWidth, rectangleTopEdge + rectangleHeight, paint);

            for (int i = 0; i < 4; i++)
            {
                paint.setARGB(255, (int)(Math.random() * 256), (int)(Math.random() * 256), (int)(Math.random() * 256));
                int smallSquareWidth = (int) (rectangleHeight * Math.random());
                int smallSquareLeft = (int)(Math.random() * (rectangleLeftEdge + rectangleWidth - smallSquareWidth));
                int smallSquareTop = rectangleTopEdge + (int)(Math.random() * (rectangleTopEdge + rectangleHeight - smallSquareWidth));

                canvas.drawRect(smallSquareLeft, smallSquareTop, smallSquareLeft + smallSquareWidth, smallSquareTop + smallSquareWidth, paint);
            }


            // using drawLine to draw a tic tac toe board

            int tttBoardLeftEdge = 600;                     // left edge of ttt board
            int tttBoardTopEdge = 50;                       // top edge of ttt board
            int tttBoardPositionWidth = 100;                // width & height of 1 position in ttt board
            int tttBoardWidth = tttBoardPositionWidth * 3;  // total width & height of ttt board

            canvas.drawLine(tttBoardLeftEdge, tttBoardTopEdge + tttBoardPositionWidth, tttBoardLeftEdge + tttBoardWidth, tttBoardTopEdge + tttBoardPositionWidth, greenPen);      // top horizontal line
            canvas.drawLine(tttBoardLeftEdge, tttBoardTopEdge + tttBoardPositionWidth * 2, tttBoardLeftEdge + tttBoardWidth, tttBoardTopEdge + tttBoardPositionWidth * 2, greenPen);      // bottom horizontal line
            canvas.drawLine(tttBoardLeftEdge + tttBoardPositionWidth,       tttBoardTopEdge, tttBoardLeftEdge + tttBoardPositionWidth,     tttBoardTopEdge + tttBoardWidth, greenPen);      // left vertical line
            canvas.drawLine(tttBoardLeftEdge + tttBoardPositionWidth * 2,   tttBoardTopEdge, tttBoardLeftEdge + tttBoardPositionWidth * 2, tttBoardTopEdge + tttBoardWidth, greenPen);      // right vertical line

            // TODO: fill the board with 5 x's and 4 o's showing a tie game using the 'ttt' variables above &/or additional variables (no magic numbers)
            canvas.drawLine(53, 53, 97, 97, greenPen);         // half of misplaced x
            canvas.drawLine(53, 97, 97, 53, greenPen);         // half of mislaced x
            canvas.drawCircle(125, 125, 23, greenPen);         // misplaced o


            // using a Path object to store 3 line segments that form a triangle

            int triangleBase = 200;
            int triangleHeight = 100;
            int numTriangles = 3;

            Path triangle1 = new Path();
            triangle1.moveTo(0, 0);
            triangle1.lineTo(triangleBase, 0);
            triangle1.lineTo(triangleBase, triangleHeight);
            triangle1.lineTo(0, 0);
            triangle1.close();

            Path triangle2 = new Path();
            triangle2.moveTo(0, triangleHeight);
            triangle2.lineTo(0, 0);
            triangle2.lineTo(triangleBase, triangleHeight);
            triangle2.lineTo(0, triangleHeight);
            triangle2.close();

            // using offset to draw the same triangle in multiple locations

            triangle2.offset(0, triangleHeight * numTriangles);

            whiteBrush.setColor(Color.WHITE);

            for (int i = 0; i < numTriangles; i++)
            {
                triangle1.offset(0, triangleHeight);     // offset is cumulative
                canvas.drawPath(triangle1, redBrush);
                triangle2.offset(0, -100);
                canvas.drawPath(triangle2, whiteBrush);
            }

            // TODO: move the red triangles up one position

            // using drawText

            paint.setColor(Color.WHITE);
            paint.setTextSize(78);
            canvas.drawText("WYOMISSING", 0, 1200, paint);
            canvas.drawText("SPARTANS", 0, 1300, paint);

            int eggLeftEdge = 800;          // left edge of oval (egg)
            int eggTopEdge = 400;           // top edge of oval
            int eggWidth = 200;             // width of oval
            int eggHeight = 300;            // height of oval
            RectF eggBoundingRectangle = new RectF(eggLeftEdge, eggTopEdge, eggLeftEdge + eggWidth, eggTopEdge + eggHeight);
            canvas.drawOval(eggBoundingRectangle, paint);                  // oval is inscribed inside of the bounding rectangle

            canvas.drawArc(new RectF(eggLeftEdge , eggTopEdge + 100, eggLeftEdge + eggWidth, eggTopEdge + eggHeight - 100), 0, 180, false, greenPen);
            canvas.drawArc(new RectF(eggLeftEdge + 40 , eggTopEdge, eggLeftEdge + eggWidth - 40, eggTopEdge + 50), 0, 180, false, greenPen);
            // TODO: add more lines to the colored egg using trigonometry

            // using drawArc & RectF

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(4);
            RectF boundingRectangle = new RectF(0, 0, 200, 200);                    // left, top, right, bottom

            boundingRectangle.offsetTo(0, 400);                                     // offsetTo sets absolute position, offseet sets position relative to the last offset
            canvas.drawArc(boundingRectangle, 0, 90, false,  paint);                // quarter circle, bounding rectangle, startAngle, sweepAngle, useCenter, paint object

            // TODO: draw the other quarter circles (top/right, top/left, bottom/left) nearby

            boundingRectangle.offsetTo(0, 600);                                      // moving the bounding rectangle to a new position on the canvas
            canvas.drawArc(boundingRectangle, 0, 180, false,  paint);                // bottom semicircle
            boundingRectangle.offsetTo(200, 600);                                    // moving the bounding rectangle to a new position on the canvas
            canvas.drawArc(boundingRectangle, 0, -180, false,  paint);               // top semicircle

            // TODO: repeat the pattern of semicircles across the screen using a loop




        }
    }
}


